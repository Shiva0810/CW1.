package model;

public enum Role {
    ANALYST,
    DESIGNER,
    DEVELOPER;
}
